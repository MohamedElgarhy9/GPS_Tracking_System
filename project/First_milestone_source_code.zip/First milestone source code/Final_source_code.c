#include "tm4c123gh6pm.h"
#include "stdint.h"
#include <stdio.h>
#include <math.h>
#define RED 0x02
#define BLUE 0x04
#define GREEN 0x08

#define _CRT_SECURE_NO_WARNINGS
#define R 6371000
#define PI 3.1415926536
#define TO_RAD (3.1415926536 / 180)

void SystemInit(){}
	
	void Delay(int x) {
    int i;
    int j;
    for (i = 0; i < x; i++) {
        for (j = 0; j < x; j++) {}
    }
}
	
	void LCD_Command(char com){
    GPIO_PORTA_DATA_R=0;
    GPIO_PORTB_DATA_R=com;
    GPIO_PORTA_DATA_R |=0x80;
    Delay(500);
    GPIO_PORTA_DATA_R=0;


    }
void LCD_DATA(char data){
    GPIO_PORTA_DATA_R=0x20;
    GPIO_PORTB_DATA_R=data;
    GPIO_PORTA_DATA_R |=0x80;
    Delay(500);
    GPIO_PORTA_DATA_R=0;
        }


void Init(void){
        SYSCTL_RCGCGPIO_R |= 0x03;
                while ((SYSCTL_PRGPIO_R&0x03) == 0){};
        GPIO_PORTA_LOCK_R = 0x4C4F434B;
        GPIO_PORTB_LOCK_R = 0x4C4F434B;
        GPIO_PORTB_CR_R |= 0xFF;
        GPIO_PORTA_CR_R |= 0xE0;
        GPIO_PORTB_DIR_R|=0xFF;
        GPIO_PORTB_DEN_R|=0xFF;
        GPIO_PORTA_DIR_R|=0xE0;
        GPIO_PORTA_DEN_R|=0xE0;
        GPIO_PORTB_AFSEL_R=0;
        GPIO_PORTB_AMSEL_R=0;
        GPIO_PORTB_PCTL_R=0;
        LCD_Command(0x01);
        LCD_Command(0x02);
        LCD_Command(0x06);
        LCD_Command(0x0F);
        LCD_Command(0x30);
        LCD_Command(0x38);

}

	
void LEDSinit (void)
{
SYSCTL_RCGCGPIO_R |= 0x20;
while ((SYSCTL_PRGPIO_R&0x20) == 0){};
GPIO_PORTF_LOCK_R = 0x4C4F434B;
GPIO_PORTF_CR_R |= 0x0E;
GPIO_PORTF_DIR_R |= 0X0E;
GPIO_PORTF_DEN_R |= 0x0E;
GPIO_PORTF_AMSEL_R &= ~0x0E;
GPIO_PORTF_AFSEL_R &=~0x0E;
GPIO_PORTF_PCTL_R &= ~0x0000FFF0;


}

double dist(double th1, double ph1, double th2, double ph2)
{
    double dx, dy, dz;
    ph1 -= ph2;
    ph1 *= TO_RAD, th1 *= TO_RAD, th2 *= TO_RAD;

    dz = sin(th1) - sin(th2);
    dx = cos(ph1) * cos(th1) - cos(th2);
    dy = sin(ph1) * cos(th1);
    return asin(sqrt(dx * dx + dy * dy + dz * dz) / 2) * 2 * R;
}

int main()
{
		LEDSinit();
	      Init();
	    
    double Lat1, Lon1, Lat2, Lon2;
    scanf("%lf", &Lat1 );
    scanf("%lf", &Lon1);  //these coordinates will be taken from GPS but now we assume it.
    scanf("%lf", &Lat2);
    scanf("%lf", &Lon2);
    double distance = dist(Lat1, Lon1, Lat2, Lon2);
    Delay(100);
	
	
	if ( distance > 100)
	{
		GPIO_PORTF_DATA_R = RED;
		
	}
	else {
    while (distance <= 100) 
			{
			
        Lat1 = Lat2;
        Lon1 = Lon2;
        scanf("%lf", &Lat2);
        scanf("%lf", &Lon2);
        distance += dist(Lat1, Lon1, Lat2, Lon2);
				
    }    //we will stop calculating distance along the path when it exceeds 100 meters

			if ( distance > 100)
	{
		GPIO_PORTF_DATA_R = RED;
		
	}

		
}
						LCD_DATA('1');
            Delay(500);
            LCD_DATA('0');
	}
