#ifndef DISTANCE_H_INCLUDED
#define DISTANCE_H_INCLUDED
#include "math.h"
#include "stdlib.h"
#include "stdint.h"

long double dist(long double th1,long double ph1,long double th2,long double ph2);

#endif