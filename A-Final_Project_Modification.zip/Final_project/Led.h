#ifndef LED_H_INCLUDED
#define LED_H_INCLUDED
#include "tm4c123gh6pm.h"
#include "stdint.h"

void LEDSinit();
void DETECT_DISTANCE();

#endif