#ifndef DELAY_H_INCLUDED
#define DELAY_H_INCLUDED
#include "tm4c123gh6pm.h"
#include "stdint.h"

void Delay(int x);

#endif