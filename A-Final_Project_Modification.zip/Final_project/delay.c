#include "tm4c123gh6pm.h"
#include <stdint.h>
#include "delay.h"
void Delay(int x){
    int i;
    int j;
    for(i=0;i<x;i++){
        for(j=0;j<x;j++){}
        }
    }