#ifndef LCD_TRACKING_H_INCLUDED
#define LCD_TRACKING_H_INCLUDED

#include "tm4c123gh6pm.h"
#include "stdint.h"
#include "Lcd_Function.h"

void lcd_routing(uint32_t Moved_dist);

#endif